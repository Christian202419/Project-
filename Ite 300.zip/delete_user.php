<?php

include("config.php");

if (isset($_GET["id"])) {
    $id = $_GET["id"];

  
    $sql = "DELETE FROM login WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php"); 
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "Student not found.";
    exit;
}
?>
